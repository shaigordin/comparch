# Original documentation is available at: http://www2.stat.duke.edu/~sayan/auto3dgm/Instructions/index.html
rm(list=ls()) # remove objects from environment

### if libraries are not installed, you should run this part
# install.packages("Matrix")
# install.packages("clue")
# install.packages("lpSolve")
# install.packages("linprog")
# install.packages("igraph")
# install.packages("MASS")
# install.packages("geomorph")

### load packages
library(Matrix)
library(clue)
library(lpSolve)
library(linprog)
library(igraph)
library(MASS)
library(geomorph)

### specify path to package folder
dir="C:/auto3dgm_example/auto3dgm/R/"
fil <- list.files(dir); i=1; for (i in 1:length(fil)) { source(paste(dir,fil[i],sep="")) }

### specify paths to folders
Data_dir = "C:/auto3dgm_example/teeth_dataset"    #  folder with files containing 3D models
Output_dir = "C:/auto3dgm_example/output"         #  folder with files containing 3D models

### specify parameters
Levels=c(64,128)      # number of points for initial and final alignement

### specify individuals you want to analyse
### variante 1 - analyse of 5 individuals 
Ids = c('001','002','003','004','005')    # Ids of 5 individuals
Names = c('a01','a02','a03','a04','a05')  # Names of 5 individuals
#### variante 2 - analyse of 15 individuals
# Ids = c('001','002','003','004','005', '006', '007', '008', '009', '010', '011', '012', '013', '014', '015')  
# Names = c('a01','a02','a03','a04','a05', 'a06', 'a07', 'a08', 'a09', 'a10', 'a11', 'a12', 'a13', 'a14', 'a15')


### run analysis
FULL = align_shapes(Data_dir, Output_dir, Levels, Ids, Names) #FULL is a list of 3 returned elements.  The user gets to specify what is returned.

### check result - each of these three returned items is useful in identifying and fixing  misaligned shapes.  
ds = FULL[[1]]      # the whole shape dataset.
ga_full=FULL[[2]]   # the global alignment 
pa=FULL[[3]]        # the pairwise alignments.

### export results of final alignement to csv file
A <- read.morphologika(paste(Output_dir,"/morphologika_2.txt",sep=""))  # coordinates of all aligned individuals (size accounted)
shape <- two.d.array(A)
write.csv(shape, paste(Output_dir,"/coords.csv",sep=""))


### you can perform analyses in R or PAST...
